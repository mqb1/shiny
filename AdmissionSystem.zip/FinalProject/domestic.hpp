#ifndef DOMESTIC_HPP
#define DOMESTIC_HPP
#include <iostream>
#include <string>
#include "student.hpp"
using namespace std;

class domestic : public student
{
private:
    string province;
    domestic *nextDomestic;

public:
    domestic(void);
    domestic(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newProvince);
    void setProvince(const string &newProvince);
    void setNextDomestic(domestic *newNextDomestic);
    string getProvince(void) const;
    domestic *getNextDomestic(void) const;
    friend int compareProvince(const domestic &domestic1, const domestic &domestic2);
    friend ostream &operator<<(ostream &outs, const domestic &domestic1);
};
#endif