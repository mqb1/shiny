#include <iostream>
#include <string>
#include "student.hpp"
#include "international.hpp"
#include "internationallist.hpp"
#include "toefl.hpp"
using namespace std;

internationalList::internationalList(void)
{
    head = NULL;
    tail = NULL;
}

internationalList::~internationalList(void)
{
    if (head != NULL)
    {
        international *current;
        while (head != NULL)
        {
            current = head;
            head = head->getNextInternational();
            delete current;
        }
    }
}

internationalList::internationalList(const internationalList &list)
{
    international *current = list.getHead();
    TOEFL toeflScore;
    while (current != NULL)
    {
        toeflScore.setScore(current->getReadingScore(), current->getListeningScore(), current->getSpeakingScore(), current->getWritingScore());
        insertInternational(current->getFirstName(), current->getLastName(), current->getCGPA(), current->getResearchScore(), current->getStudentID(), current->getCountry(), toeflScore);
        current = current->getNextInternational();
    }
}

void internationalList::searchID(int x) const
{
    international *current = head; // Initialize current
    int count = 0;
    while (current != NULL)
    {
        if (current->getStudentID() == x)
        {
            cout << *current;
            count++;
        }
        current = current->getNextInternational();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void internationalList::searchCGPA(int x) const
{
    international *current = head; // Initialize current
    int count = 0;
    while (current != NULL)
    {
        if (current->getCGPA() == x)
        {
            cout << *current;
            count++;
        }
        current = current->getNextInternational();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void internationalList::searchResearchScore(int x) const
{
    international *current = head; // Initialize current
    int count = 0;
    while (current != NULL)
    {
        if (current->getResearchScore() == x)
        {
            cout << *current;
            count++;
        }
        current = current->getNextInternational();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void internationalList::searchName(string firstName, string lastName) const
{
    unsigned int count = 0;
    unsigned int matchLastName = 0;
    unsigned int matchFirstName = 0;
    unsigned int index = 0;
    international *current = head; // Initialize current
    while (current != NULL)
    {
        if (current->getFirstName().length() == firstName.length() && current->getLastName().length() == lastName.length())
        {
            for (unsigned int index = 0; index < firstName.length(); index++)
            {
                if (current->getFirstName()[index] == firstName[index] || current->getFirstName()[index] == (firstName[index] + 32) || current->getFirstName()[index] == (firstName[index] - 32))
                {
                    matchFirstName++;
                }
            }
            for (unsigned int index = 0; index < lastName.length(); index++)
            {
                if (current->getLastName()[index] == lastName[index] || current->getLastName()[index] == (lastName[index] + 32) || current->getLastName()[index] == (lastName[index] - 32))
                {
                    matchLastName++;
                }
            }
        }
        if (matchFirstName == firstName.length() && matchLastName == lastName.length())
        {
            cout << *current;
            count++;
        }
        matchLastName = 0;
        matchFirstName = 0;
        current = current->getNextInternational();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void internationalList::deleteInternational(const string &firstName, const string &lastName)
{
    unsigned int matchLastName = 0;
    unsigned int matchFirstName = 0;
    unsigned int index = 0;
    international *current = head; // Initialize current
    international *before = head;
    while (current != NULL)
    {
        if (current->getFirstName().length() == firstName.length() && current->getLastName().length() == lastName.length())
        {
            for (unsigned int index = 0; index < firstName.length(); index++)
            {
                if (current->getFirstName()[index] == firstName[index] || current->getFirstName()[index] == (firstName[index] + 32) || current->getFirstName()[index] == (firstName[index] - 32))
                {
                    matchFirstName++;
                }
            }
            for (unsigned int index = 0; index < lastName.length(); index++)
            {
                if (current->getLastName()[index] == lastName[index] || current->getLastName()[index] == (lastName[index] + 32) || current->getLastName()[index] == (lastName[index] - 32))
                {
                    matchLastName++;
                }
            }
        }
        if (matchFirstName == firstName.length() && matchLastName == lastName.length())
        {
            if (current->getStudentID() == head->getStudentID())
            {
                head = head->getNextInternational();
                delete current;
            }
            if (current->getStudentID() == tail->getStudentID())
            {
                tail = NULL;
                delete current;
            }
            else
            {
                before->setNextInternational(current->getNextInternational());
                delete current;
            }
        }
        matchLastName = 0;
        matchFirstName = 0;
        before = current;
        current = current->getNextInternational();
    }
}

void internationalList::insertInternational(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newCountry, const TOEFL &newToeflScore)
{
    if (newToeflScore.getTotalScore() >= 93 || newToeflScore.getWritingScore() > 20 || newToeflScore.getReadingScore() > 20 || newToeflScore.getListeningScore() > 20 || newToeflScore.getSpeakingScore() > 20)
    {
        international *internationalStudent = new international;
        internationalStudent->setCGPA(newCGPA);
        internationalStudent->setfirstName(newFirstName);
        internationalStudent->setlastName(newLastName);
        internationalStudent->setCountry(newCountry);
        internationalStudent->setResearchScore(newResearchScore);
        internationalStudent->setStudentID(newStudentID);
        internationalStudent->setTOEFL(newToeflScore);
        if (head == NULL || compareResearchScore(*head, *internationalStudent) == 3 || compareResearchScore(*head, *internationalStudent) == 1 && compareCGPA(*head, *internationalStudent) == 3 || compareResearchScore(*head, *internationalStudent) == 1 && compareCGPA(*head, *internationalStudent) == 1 && compareCountry(*head, *internationalStudent) == 3)
        {
            internationalStudent->setNextInternational(head);
            head = internationalStudent;
        }
        else
        {
            international *current = head;
            while (current->getNextInternational() != NULL && compareResearchScore(*current->getNextInternational(), *internationalStudent) == 2)
            {
                current = current->getNextInternational();
            }
            while (current->getNextInternational() != NULL && compareResearchScore(*current->getNextInternational(), *internationalStudent) == 1 && compareCGPA(*current->getNextInternational(), *internationalStudent) == 2)
            {
                current = current->getNextInternational();
            }
            while (current->getNextInternational() != NULL && compareResearchScore(*current->getNextInternational(), *internationalStudent) == 1 && compareCGPA(*current->getNextInternational(), *internationalStudent) == 1 && compareCountry(*current->getNextInternational(), *internationalStudent) == 2)
            {
                current = current->getNextInternational();
            }
            if (current == NULL)
            {
                tail = internationalStudent;
            }
            internationalStudent->setNextInternational(current->getNextInternational());
            current->setNextInternational(internationalStudent);
        }
    }
}

void internationalList::deleteHeadTail(void)
{
    if (head != NULL && head != tail)
    {
        international *temp_ptr = head;
        head = head->getNextInternational();
        delete temp_ptr;
        international *secondLast = head;
        while (secondLast->getNextInternational()->getNextInternational() != NULL)
        {
            secondLast = secondLast->getNextInternational();
        }
        delete (secondLast->getNextInternational());
        tail = secondLast;
    }
    if (head != NULL && head == tail)
    {
        delete head;
    }
}
international *internationalList::getHead(void) const
{
    return head;
}

internationalList &internationalList::operator=(const internationalList &list)
{
    if (this == &list)
    {
        return *this;
    }
    else
    {
        international *current = list.getHead();
        TOEFL toeflScore;
        while (current != NULL)
        {
            toeflScore.setScore(current->getReadingScore(), current->getListeningScore(), current->getSpeakingScore(), current->getWritingScore());
            insertInternational(current->getFirstName(), current->getLastName(), current->getCGPA(), current->getResearchScore(), current->getStudentID(), current->getCountry(), toeflScore);
            current = current->getNextInternational();
        }
        return *this;
    }
}

ostream &operator<<(ostream &outs, const internationalList &list)
{
    outs << "Your list:" << endl
         << endl;
    international *current = list.getHead();
    while (current != NULL)
    {
        outs << *current << endl;
        current = current->getNextInternational();
    }
    return outs;
}