#ifndef DOMESTICLIST_HPP
#define DOMESTICLIST_HPP
#include <iostream>
#include <string>
#include "student.hpp"
#include "domestic.hpp"
using namespace std;

class domesticList
{
private:
    domestic *head;
    domestic *tail;
public:
    domesticList(void);
    ~domesticList(void);
    domesticList(const domesticList &list);
    void searchID(int x) const;
    void searchCGPA(int x) const;
    void searchResearchScore(int x) const;
    void searchName(string firstName, string lastName) const;
    void deleteDomestic(const string& firstName, const string& lastName );
    void deleteHeadTail(void);
    void insertDomestic(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newProvince);
    domestic *getHead(void) const;
    domestic *getTail(void) const;
    domesticList &operator=(const domesticList &list);
    friend ostream &operator<<(ostream &outs, const domesticList &list);
};

#endif