#include <iostream>
#include <string>
#include "student.hpp"
#include "domestic.hpp"
using namespace std;

domestic::domestic(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newProvince)
    : student(newFirstName, newLastName, newCGPA, newResearchScore, newStudentID)
{
    province = newProvince;
    nextDomestic = NULL;
    setStudentType(1);
}

domestic::domestic() : student()
{
    nextDomestic = NULL;
    setStudentType(1);
}

void domestic::setProvince(const string &newProvince)
{
    province = newProvince;
}

void domestic::setNextDomestic(domestic *newNextDomestic)
{
    nextDomestic = newNextDomestic;
}

string domestic::getProvince(void) const
{
    return province;
}

domestic *domestic::getNextDomestic(void) const
{
    return nextDomestic;
}

int compareProvince(const domestic &domestic1, const domestic &domestic2)
{
    unsigned int index = 0;
    while (domestic1.province[index] == domestic2.province[index] && index < domestic1.province.size() && index < domestic2.province.size())
    {
        index++; // find the part of the 2 name strings that is different
    }
    if (index != (domestic1.province.size()-1) && index != (domestic1.province.size()-1)) // check which one comes Last
    {
        if (domestic1.province[index] < domestic2.province[index])
        {
            return 2;
        }
        else
        {
            return 3;
        }
    }
    else
    {
        return 1; // returns 1 when the two strings is identical
    }
}

ostream &operator<<(ostream &outs, const domestic &domestic1)
{
    outs << "Student name: " << domestic1.getFirstName() << " " << domestic1.getLastName() << endl;
    outs << "Student ID:" << domestic1.getStudentID() << endl;
    outs << "Research Score: " << domestic1.getResearchScore() << endl;
    outs << "CGPA: " << domestic1.getCGPA() << endl;
    outs << "Province: " << domestic1.province << endl;
    return outs;
}