// student.cpp to implement your classes
#include "student.hpp"
#include <iostream>
#include <string>
using namespace std;

// Constructor
student::student()
{
    string firstName = "FirstName";
    string lastName = "LastName";
    float CGPA = 0;
    int researchScore = 0;
    int StudentID = 0;
    int studentType = 0;
}
student::student(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID)
{
    firstName = newFirstName;
    lastName = newLastName;
    researchScore = newResearchScore;
    StudentID = newStudentID;
    CGPA = newCGPA;
}

// Setting
void student::setfirstName(const string &newFirstName)
{
    firstName = newFirstName;
}

void student::setlastName(const string &newLastName)
{

    lastName = newLastName;
}

void student::setCGPA(const float &newCGPA)
{
    CGPA = newCGPA;
}

void student::setResearchScore(const int &newResearchScore)
{
    researchScore = newResearchScore;
}

void student::setStudentID(const int &newStudentID)
{

    StudentID = newStudentID;
}

void student::setStudentType(const int &newStudentType)
{
    studentType = newStudentType;
}

// Getting
string student::getFirstName(void) const
{
    return firstName;
}

string student::getLastName(void) const
{
    return lastName;
}

int student::getResearchScore(void) const
{
    return researchScore;
}

int student::getStudentID(void) const
{
    return StudentID;
}

float student::getCGPA(void) const
{
    return CGPA;
}

int student::getStudentType(void) const
{
    return studentType;
}

int compareResearchScore(const student &student1, const student &student2)
{
    if (student1.getResearchScore() >= 0 && student1.getResearchScore() <= 100 && student2.getResearchScore() >= 0 && student2.getResearchScore() <= 100)
    {
        if (student1.getResearchScore() == student2.getResearchScore())
        {
            return 1;
        }
        if (student1.getResearchScore() > student2.getResearchScore())
        {
            return 2;
        }
        if (student1.getResearchScore() < student2.getResearchScore())
        {
            return 3;
        }
    }
    else
    {
        cout << "Research Score Invalid" << endl;
        return 0;
    }
}

int compareCGPA(const student &student1, const student &student2)
{
    if (student1.getCGPA() >= 0 && student1.getCGPA() <= 4.33 && student2.getCGPA() >= 0 && student2.getCGPA() <= 4.33)
    {
        if (student1.getCGPA() == student2.getCGPA())
        {
            return 1;
        }
        if (student1.getCGPA() > student2.getCGPA())
        {
            return 2;
        }
        if (student1.getCGPA() < student2.getCGPA())
        {
            return 3;
        }
    }
    else
    {
        cout << "CGPA Invalid" << endl;
        return 0;
    }
}

int compareFirstName(const student &student1, const student &student2)
{
    unsigned int index = 0;
    while (student1.firstName[index] == student2.firstName[index] && index < student1.firstName.size() && index < student2.firstName.size())
    {
        index++; // find the part of the 2 name strings that is different
    }
    if (index != (student1.lastName.size() - 1) && index != (student2.lastName.size() - 1)) // check which one comes first
    {
        if (student1.firstName[index] < student2.firstName[index])
        {
            return 2;
        }
        else
        {
            return 3;
        }
    }
    else
    {
        return 1; // returns 1 when the two strings is identical
    }
}

int compareLastName(const student &student1, const student &student2)
{
    unsigned int index = 0;
    while (student1.lastName[index] == student2.lastName[index] && index < student1.lastName.size() && index < student2.lastName.size())
    {
        index++; // find the part of the 2 name strings that is different
    }
    if (index != (student1.lastName.size() - 1) && index != (student2.lastName.size() - 1)) // check which one comes Last
    {
        if (student1.lastName[index] < student2.lastName[index])
        {
            return 2;
        }
        else
        {
            return 3;
        }
    }
    else
    {
        return 1; // returns 1 when the two strings is identical
    }
}
