#ifndef INTERNATIONALLIST_HPP
#define INTERNATIONALLIST_HPP
#include <iostream>
#include <string>
#include "student.hpp"
#include "international.hpp"
#include "toefl.hpp"
using namespace std;

class internationalList
{
private:
    international *head;
    international *tail;

public:
    internationalList(void);
    ~internationalList(void);
    internationalList(const internationalList &List);
    void searchID(int x) const;
    void searchCGPA(int x) const;
    void searchResearchScore(int x) const;
    void searchName(string firstName, string lastName) const;
    void deleteInternational(const string &firstName, const string &lastName);
    void deleteHeadTail(void);
    void insertInternational(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newCountry, const TOEFL &newToeflScore);
    international *getHead(void) const;
    international *getTail(void) const;
    internationalList &operator=(const internationalList &list);
    friend ostream &operator<<(ostream &outs, const internationalList &List);
};

#endif