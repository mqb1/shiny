#include <iostream>
#include <string>
#include "student.hpp"
#include "toefl.hpp"
#include "international.hpp"
using namespace std;

international::international() : student()
{
    nextInternational = NULL;
    setStudentType(2);
}

international::international(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newCountry, const TOEFL &newToeflScore)
    : student(newFirstName, newLastName, newCGPA, newResearchScore, newStudentID)
{
    toeflScore.setScore(newToeflScore.getReadingScore(), newToeflScore.getListeningScore(), newToeflScore.getSpeakingScore(), newToeflScore.getWritingScore());
    country = newCountry;
    nextInternational = NULL;
    setStudentType(2);
}

void international::setCountry(const string &newCountry)
{
    country = newCountry;
}

void international::setTOEFL(const TOEFL &newTOEFL)
{
    toeflScore.setScore(newTOEFL.getReadingScore(), newTOEFL.getListeningScore(), newTOEFL.getSpeakingScore(), newTOEFL.getWritingScore());
}

void international::setNextInternational(international *newNextInternaitonal)
{
    nextInternational = newNextInternaitonal;
}

string international::getCountry()
{
    return country;
}

international *international::getNextInternational(void) const
{
    return nextInternational;
}

int compareCountry(const international &international1, const international &international2)
{
    unsigned int index = 0;
    while (international1.country[index] == international2.country[index] && index < international1.country.size() && index < international2.country.size())
    {
        index++; // find the part of the 2 name strings that is different
    }
    if (index != (international1.country.size() - 1) && index != (international1.country.size() - 1)) // check which one comes Last
    {
        if (international1.country[index] < international2.country[index])
        {
            return 2;
        }
        else
        {
            return 3;
        }
    }
    else
    {
        return 1; // returns 1 when the two strings is identical
    }
}

ostream &operator<<(ostream &outs, const international &international1)
{
    outs << "Student name: " << international1.getFirstName() << " " << international1.getLastName() << endl;
    outs << "Student ID:" << international1.getStudentID() << endl;
    outs << "Research Score: " << international1.getResearchScore() << endl;
    outs << "CGPA: " << international1.getCGPA() << endl;
    outs << "Country: " << international1.country << endl;
    outs << "TOEFL Score: " << endl;
    outs << "Reading: " << international1.toeflScore.getReadingScore() << " ";
    outs << "Listening: " << international1.toeflScore.getListeningScore() << " ";
    outs << "Speaking: " << international1.toeflScore.getSpeakingScore() << " ";
    outs << "Writing: " << international1.toeflScore.getWritingScore() << " ";
    outs << "Total: " << international1.toeflScore.getTotalScore() << endl;
    return outs;
}

int international::getReadingScore(void) const
{
    return toeflScore.getReadingScore();
}
int international::getListeningScore(void) const
{
    return toeflScore.getListeningScore();
}
int international::getSpeakingScore(void) const
{
    return toeflScore.getSpeakingScore();
}
int international::getWritingScore(void) const
{
    return toeflScore.getWritingScore();
}
int international::getTotalScore(void) const
{
    return toeflScore.getTotalScore();
}