#ifndef TOEFL_HPP
#define TOEFL_HPP
#include <iostream>
using namespace std;

class TOEFL
{
private:
    int readingScore;
    int listeningScore;
    int speakingScore;
    int writingScore;
    int totalScore;

public:
    TOEFL();
    TOEFL(const int newReadingScore, const int newListeningScore, const int newSpeakingScore, const int newWritingScore);
    void setScore(const int newReadingScore, const int newListeningScore, const int newSpeakingScore, const int newWritingScore);
    int getReadingScore(void) const;
    int getListeningScore(void) const;
    int getSpeakingScore(void) const;
    int getWritingScore(void) const;
    int getTotalScore(void) const;
};
#endif