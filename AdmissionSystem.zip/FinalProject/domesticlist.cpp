#include <iostream>
#include <string>
#include "student.hpp"
#include "domestic.hpp"
#include "domesticlist.hpp"
using namespace std;

domesticList::domesticList(void)
{
    head = NULL;
    tail = NULL;
}

domesticList::~domesticList(void)
{
    if (head != NULL)
    {
        domestic *current;
        while (head != NULL)
        {
            current = head;
            head = head->getNextDomestic();
            delete current;
        }
    }
}

domesticList::domesticList(const domesticList &list)
{
    domestic *current = list.getHead();
    while (current != NULL)
    {
        insertDomestic(current->getFirstName(), current->getLastName(), current->getCGPA(), current->getResearchScore(), current->getStudentID(), current->getProvince());
        current = current->getNextDomestic();
    }
}

void domesticList::searchID(int x) const
{
    domestic *current = head; // Initialize current
    unsigned int count = 0;
    while (current != NULL)
    {
        if (current->getStudentID() == x)
        {
            cout << *current;
            count++;
        }
        current = current->getNextDomestic();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void domesticList::searchCGPA(int x) const
{
    domestic *current = head; // Initialize current
    unsigned int count = 0;
    while (current != NULL)
    {
        if (current->getCGPA() == x)
        {
            cout << *current;
            count++;
        }
        current = current->getNextDomestic();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void domesticList::searchResearchScore(int x) const
{
    domestic *current = head; // Initialize current
    unsigned int count = 0;
    while (current != NULL)
    {
        if (current->getResearchScore() == x)
        {
            cout << *current;
            count++;
        }
        current = current->getNextDomestic();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void domesticList::searchName(string firstName, string lastName) const
{
    unsigned int count = 0;
    unsigned int matchLastName = 0;
    unsigned int matchFirstName = 0;
    unsigned int index = 0;
    domestic *current = head; // Initialize current
    while (current != NULL)
    {
        if (current->getFirstName().length() == firstName.length() && current->getLastName().length() == lastName.length())
        {
            for (unsigned int index = 0; index < firstName.length(); index++)
            {
                if (current->getFirstName()[index] == firstName[index] || current->getFirstName()[index] == (firstName[index] + 32) || current->getFirstName()[index] == (firstName[index] - 32))
                {
                    matchFirstName++;
                }
            }
            for (unsigned int index = 0; index < lastName.length(); index++)
            {
                if (current->getLastName()[index] == lastName[index] || current->getLastName()[index] == (lastName[index] + 32) || current->getLastName()[index] == (lastName[index] - 32))
                {
                    matchLastName++;
                }
            }
        }
        if (matchFirstName == firstName.length() && matchLastName == lastName.length())
        {
            cout << *current;
            count++;
        }
        matchLastName = 0;
        matchFirstName = 0;
        current = current->getNextDomestic();
    }
    if (count == 0)
    {
        cout << "No match found" << endl;
    }
}

void domesticList::deleteDomestic(const string &firstName, const string &lastName)
{
    unsigned int matchLastName = 0;
    unsigned int matchFirstName = 0;
    unsigned int index = 0;
    domestic *current = head; // Initialize current
    domestic *before = head;
    while (current != NULL)
    {
        if (current->getFirstName().length() == firstName.length() && current->getLastName().length() == lastName.length())
        {
            for (unsigned int index = 0; index < firstName.length(); index++)
            {
                if (current->getFirstName()[index] == firstName[index] || current->getFirstName()[index] == (firstName[index] + 32) || current->getFirstName()[index] == (firstName[index] - 32))
                {
                    matchFirstName++;
                }
            }
            for (unsigned int index = 0; index < lastName.length(); index++)
            {
                if (current->getLastName()[index] == lastName[index] || current->getLastName()[index] == (lastName[index] + 32) || current->getLastName()[index] == (lastName[index] - 32))
                {
                    matchLastName++;
                }
            }
        }
        if (matchFirstName == firstName.length() && matchLastName == lastName.length())
        {
            if (current->getStudentID() == head->getStudentID())
            {
                head = head->getNextDomestic();
                delete current;
            }
            if (current->getStudentID() == tail->getStudentID())
            {
                tail = NULL;
                delete current;
            }
            else
            {
                before->setNextDomestic(current->getNextDomestic());
                delete current;
            }
        }
        matchLastName = 0;
        matchFirstName = 0;
        before = current;
        current = current->getNextDomestic();
    }
}

void domesticList::deleteHeadTail(void)
{
    if (head != NULL && head != tail)
    {
        cout << "head not tail" << endl;
        domestic *temp_ptr = head;
        head = head->getNextDomestic();
        delete temp_ptr;
        domestic *secondLast = head;
        while (secondLast->getNextDomestic()->getNextDomestic() != NULL)
        {
            secondLast = secondLast->getNextDomestic();
        }
        cout << *secondLast->getNextDomestic() << endl;
        delete secondLast->getNextDomestic();
        tail = secondLast;
    }
    if (head != NULL && head == tail)
    {
        delete head;
        cout << "head is tail" << endl;
        return;
    }
}

void domesticList::insertDomestic(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newProvince)
{
    domestic *domesticStudent = new domestic;
    domesticStudent->setCGPA(newCGPA);
    domesticStudent->setfirstName(newFirstName);
    domesticStudent->setlastName(newLastName);
    domesticStudent->setProvince(newProvince);
    domesticStudent->setResearchScore(newResearchScore);
    domesticStudent->setStudentID(newStudentID);
    if (head == NULL || compareResearchScore(*head, *domesticStudent) == 3 || compareResearchScore(*head, *domesticStudent) == 1 && compareCGPA(*head, *domesticStudent) == 3 || compareResearchScore(*head, *domesticStudent) == 1 && compareCGPA(*head, *domesticStudent) == 1 && compareProvince(*head, *domesticStudent) == 3)
    {
        domesticStudent->setNextDomestic(head);
        head = domesticStudent;
    }
    else
    {
        domestic *current = head;
        while (current->getNextDomestic() != NULL && compareResearchScore(*current->getNextDomestic(), *domesticStudent) == 2)
        {
            current = current->getNextDomestic();
        }
        while (current->getNextDomestic() != NULL && compareResearchScore(*current->getNextDomestic(), *domesticStudent) == 1 && compareCGPA(*current->getNextDomestic(), *domesticStudent) == 2)
        {
            current = current->getNextDomestic();
        }
        while (current->getNextDomestic() != NULL && compareResearchScore(*current->getNextDomestic(), *domesticStudent) == 1 && compareCGPA(*current->getNextDomestic(), *domesticStudent) == 1 && compareProvince(*current->getNextDomestic(), *domesticStudent) == 2)
        {
            current = current->getNextDomestic();
        }
        if(current == NULL)
        {
            tail = domesticStudent;
        }
        domesticStudent->setNextDomestic(current->getNextDomestic());
        current->setNextDomestic(domesticStudent);
    }
}

domestic *domesticList::getHead(void) const
{
    return head;
}

domestic *domesticList::getTail(void) const
{
    return tail;
}

domesticList &domesticList::operator=(const domesticList &list)
{
    if (this == &list)
    {
        return *this;
    }
    else
    {
        domestic *current = list.getHead();
        while (current != NULL)
        {
            insertDomestic(current->getFirstName(), current->getLastName(), current->getCGPA(), current->getResearchScore(), current->getStudentID(), current->getProvince());
            current = current->getNextDomestic();
        }
        return *this;
    }
}

ostream &operator<<(ostream &outs, const domesticList &list)
{
    outs << "Your list:" << endl
         << endl;
    domestic *current = list.getHead();
    while (current != NULL)
    {
        outs << *current << endl;
        current = current->getNextDomestic();
    }
    return outs;
}