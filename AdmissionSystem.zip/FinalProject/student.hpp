// header file student.hpp to declare your classes
#ifndef STUDENT_HPP
#define STUDENT_HPP
#include <iostream>
#include <string>
using namespace std;

class student
{
private:
    string firstName;
    string lastName;
    float CGPA;
    int researchScore;
    int StudentID;
    int studentType;


public:
    student();
    student(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID);
    void setfirstName(const string &newFirstName);
    void setlastName(const string &newLastName);
    void setCGPA(const float &newCGPA);
    void setResearchScore(const int &newResearchScore);
    void setStudentID(const int &newStudentID);
    void setStudentType(const int &num);
    int getStudentType(void) const;
    string getFirstName(void) const;
    string getLastName(void) const;
    float getCGPA(void) const;
    int getResearchScore(void) const;
    int getStudentID(void) const;
    friend int compareCGPA(const student &student1, const student &student2);          // returns 1 if equal; 2 if stu 1>2; 3 if 1<2
    friend int compareResearchScore(const student &student1, const student &student2); // returns 1 if equal; 2 if stu 1>2; 3 if 1<2
    friend int compareFirstName(const student &student1, const student &student2);     // 1 if 1 comes before 2 e.g: Alex & Mary, 2 if 1 is same as 2 e.g: Michael & Mortis, 3 if 1 comes after 2, e.g: Mary & Alex
    friend int compareLastName(const student &student1, const student &student2);      // Same as above
};

#endif