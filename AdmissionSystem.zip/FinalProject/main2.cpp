#include <iostream> //cin and cout
#include <fstream>  //file processing
#include <sstream>  //formatted string processing
#include <cstdlib>  //atof and atoi
#include "student.hpp"
#include "international.hpp"
#include "domestic.hpp"
#include "toefl.hpp"
#include "domesticlist.hpp"
#include "internationallist.hpp"
#define MAX_SIZE (100)

int main(void)
{
    // First, we need to read all the data from the text file
    string line;

    // Declaring objects
    domesticList D;
    internationalList I;
    TOEFL T[MAX_SIZE];

    ifstream domesticFile("domestic-stu.txt");
    if (!domesticFile.is_open())
    {
        cout << "Unable to open file domestic-stu.txt" << endl;
        return -1;
    }

    // Read the first line of domestic-stu.txt, which specifies
    // the file format. And then print it out to the screen
    getline(domesticFile, line);
    cout << "File format: " << line << endl;

    int dom_count = 0;
    int stu_id1 = 20220000; // student id

    string validProvinces[13] = {"NL", "PE", "NS", "NB", "QC", "ON", "MB", "SK", "AB",
                                 "BC", "YT", "NT", "NU"};

    while (getline(domesticFile, line))
    {
        istringstream ss(line);

        string firstName, lastName, province, s_cgpa, s_researchScore;
        float cgpa;
        int researchScore;

        // get firstName separated by comma
        getline(ss, firstName, ',');

        // get lastName separated by comma
        getline(ss, lastName, ',');

        // get province separated by comma
        getline(ss, province, ',');

        // Robust error checking 3a
        // for (int i = 0; i <= 13; i++)
        //{

        //}

        // get cpga separated by comma, and convert string to float
        getline(ss, s_cgpa, ',');
        cgpa = atof(s_cgpa.c_str());

        // get researchScore separated by comma, and convert it to int
        getline(ss, s_researchScore, ',');
        researchScore = atoi(s_researchScore.c_str());

        D.insertDomestic(firstName, lastName, cgpa, researchScore, stu_id1, province);

        stu_id1++;
        dom_count++;
    }
    cout << D << endl;
    domesticFile.close();

    // international file manipulation has same code as for domestic so no comments needed
    ifstream internationalFile("international-stu.txt");
    if (!internationalFile.is_open())
    {
        cout << "Unable to open file international-stu.txt" << endl;
        return -1;
    }

    int internationalStu_count = 101;
    string validCountries[5] = {"Canada", "China", "India", "Iran", "Korea"};
    getline(internationalFile, line);
    cout << "File format: " << line << endl;

    while (getline(internationalFile, line))
    {

        istringstream ss(line);

        string firstName, lastName, country, s_cgpa, s_researchScore, s_readingScore, s_listeningScore, s_speakingScore, s_writingScore;
        float cgpa;
        int researchScore, readingScore, listeningScore, speakingScore, writingScore;

        getline(ss, firstName, ',');
        getline(ss, lastName, ',');
        getline(ss, country, ',');

        // Robust error checking 3b
        // for (int i = 0; i <= 5; i++)
        //{
        // if (country != validCountries[i])
        //{
        // if (country == "Idian")
        //{
        // cout << "Idian read in from text file. Fixing to India" << endl;
        // for(int j = 1; j <= 4; j++)
        //{
        //   char temp;
        //  temp = country[4];
        // country[j] = country[j+1];

        //}
        //}
        // else
        //  cout << "Input from text file contains an invalid country" << endl;
        //}
        //}

        getline(ss, s_cgpa, ',');
        cgpa = atof(s_cgpa.c_str());

        getline(ss, s_researchScore, ',');
        researchScore = atoi(s_researchScore.c_str());

        getline(ss, s_readingScore, ',');
        readingScore = atoi(s_readingScore.c_str());
        getline(ss, s_listeningScore, ',');
        listeningScore = atoi(s_listeningScore.c_str());
        getline(ss, s_speakingScore, ',');
        speakingScore = atoi(s_speakingScore.c_str());
        getline(ss, s_writingScore, ',');
        writingScore = atoi(s_writingScore.c_str());

        T[internationalStu_count].setScore(readingScore, listeningScore, speakingScore, writingScore);
        I.insertInternational(firstName, lastName, cgpa, researchScore, stu_id1, country, T[internationalStu_count]);

        stu_id1++;
        internationalStu_count++;
    }
    cout << I << endl;
    internationalFile.close();

    // User interface
    cout << "Type in the number of the action you would like to take" << endl;

    // declaring variables to store input
    int menu_option1 = 0, menu_option2 = 0;
    // domestic and international
    int app_id = 0;
    int res_score = 0;
    float temp_cgpa = 0.0;
    string FN = ""; // first name
    string LN = ""; // last name
    string newFirstName = "";
    string newLastName = "";
    int newResearchScore = 0;
    int newStudentID = 0;
    float newCGPA = 0.0;
    string newProvince = "";
    string FN2 = "";
    string LN2 = "";
    string newCountry = "";
    //for TOEFL
    TOEFL T2;
    int newReadingscore = 0;
    int newListeningscore = 0;
    int newSpeakingscore = 0;
    int newWritingscore = 0;
    //for merged list
    float cgpa_threshold = 0.0;
    int RS_threshold = 0;


    do
    {

        cout << "Which field would you like to access? 1 for DomesticStudent and 2 for International Student" << endl;
        cout << "If you would like to merge the list and access it, enter 3\n"
             << endl;
        cout << "If you would like to perform a unit test, press 4\n"
             << endl;

        cin >> menu_option1;

        if (menu_option1 == 1)
        {
            cout << "Type in the number of the action you would like to take: \n"
                 << endl;
            cout << "1. Search Domestic Application ID" << endl;
            cout << "2. Search Domestic Research Score" << endl;
            cout << "3. Search Domestic CGPA" << endl;
            cout << "4. Search Domestic First Name and Last Name" << endl;
            cout << "5. Insert a new Domestic Student into list" << endl;
            cout << "6. Delete a Domestic Student from list" << endl;
            cout << "7. Delete head and tail nodes from list" << endl;

            cin >> menu_option2;

            switch (menu_option2)
            {
            case 1:
                cout << "Enter the Application ID you would like to search for: " << endl;
                cin >> app_id;
                D.searchID(app_id);
                break;

            case 2:
                cout << "Enter the Research Score you would like to search for: " << endl;
                cin >> res_score;
                D.searchResearchScore(res_score);
                break;

            case 3:
                cout << "Enter the CGPA you would like to search for: " << endl;
                cin >> temp_cgpa;
                D.searchCGPA(temp_cgpa);
                break;

            case 4:
                cout << "Enter the first and last name of the student you would like to search for: " << endl;
                cin >> FN;
                cin >> LN;
                D.searchName(FN, LN);
                break;

            case 5:
                cout << "Enter the students first name:\n"
                     << endl;
                cin >> newFirstName;
                cout << "Enter the students last name:\n"
                     << endl;
                cin >> newLastName;
                cout << "Enter the students cgpa:\n"
                     << endl;
                cin >> newCGPA;
                cout << "Enter the students research score:\n"
                     << endl;
                cin >> newResearchScore;
                cout << "Enter the students student ID:\n"
                     << endl;
                cin >> newStudentID;
                cout << "Enter the students province:\n"
                     << endl;
                cin >> newProvince;

                D.insertDomestic(newFirstName, newLastName, newCGPA, newResearchScore, newStudentID, newProvince);
                break;

            case 6:
                cout << "Enter the first and last name of the student you would like to delete: " << endl;
                cin >> FN2;
                cin >> LN2;
                D.deleteDomestic(FN2, LN2);
                break;

            case 7:
                cout << "Deleting head and tail nodes of the list..." << endl;
                D.deleteHeadTail();
                break;

            default:
                cout << "The number that you have entered is not a number on the menu" << endl;
                break;
            }
        }

        if (menu_option1 == 2)
        {
            cout << "Type in the number of the action you would like to take: \n"
                 << endl;
            cout << "1. Search International Application ID" << endl;
            cout << "2. Search International Research Score" << endl;
            cout << "3. Search International CGPA" << endl;
            cout << "4. Search International First Name and Last Name" << endl;
            cout << "5. Insert a new International Student into list" << endl;
            cout << "6. Delete a International Student from list" << endl;
            cout << "7. Delete head and tail nodes from list" << endl;

            cin >> menu_option2;

            switch (menu_option2)
            {
            case 1:
                cout << "Enter the Application ID you would like to search for: " << endl;
                cin >> app_id;
                I.searchID(app_id);
                break;

            case 2:
                cout << "Enter the Research Score you would like to search for: " << endl;
                cin >> res_score;
                I.searchResearchScore(res_score);
                break;

            case 3:
                cout << "Enter the CGPA you would like to search for: " << endl;
                cin >> temp_cgpa;
                I.searchCGPA(temp_cgpa);
                break;

            case 4:
                cout << "Enter the first and last name of the student you would like to search for: " << endl;
                cin >> FN;
                cin >> LN;
                I.searchName(FN, LN);
                break;

            case 5:
                cout << "Enter the students first name:\n"
                     << endl;
                cin >> newFirstName;
                cout << "Enter the students last name:\n"
                     << endl;
                cin >> newLastName;
                cout << "Enter the students cgpa:\n"
                     << endl;
                cin >> newCGPA;
                cout << "Enter the students research score:\n"
                     << endl;
                cin >> newResearchScore;
                cout << "Enter the students student ID:\n"
                     << endl;
                cin >> newStudentID;
                cout << "Enter the students country:\n"
                     << endl;
                cin >> newCountry;
                cout << "Enter the students Reading score:\n"
                     << endl;
                cin >> newReadingscore;
                cout << "Enter the students Listening score:\n"
                     << endl;
                cin >> newListeningscore;
                cout << "Enter the students Speaking score:\n"
                     << endl;
                cin >> newSpeakingscore;
                cout << "Enter the students Writing score:\n"
                     << endl;
                cin >> newWritingscore;
                T2.setScore(newReadingscore, newListeningscore, newSpeakingscore, newWritingscore);

                I.insertInternational(newFirstName, newLastName, newCGPA, newResearchScore, newStudentID, newCountry, T2);
                break;

            case 6:
                cout << "Enter the first and last name of the student you would like to delete: " << endl;
                cin >> FN2;
                cin >> LN2;
                I.deleteInternational(FN2, LN2);
                break;

            case 7:
                cout << "Deleting head and tail nodes of the list..." << endl;
                I.deleteHeadTail();
                break;

            default:
                cout << "The number that you have entered is not a number on the menu" << endl;
                break;
            }
        }

        if (menu_option1 == 3)
        {
            // code for merging the list here
            cout << "List Merged!" << endl;
            // code for printing out the merged list here (optional)
            cout << "Enter the value of the cgpa threshold and research score threshold: \n"
                 << endl;
            cin >> cgpa_threshold;
            cin >> RS_threshold;
            // make two variables above the input of the search merged list function
        }

        if (menu_option1 == 4)
        {
            // Part 3: Unit Test

            // testing insert
            // domestic
            D.insertDomestic("Royce", "Mancilla", 3.5, 90, 20222000, "BC"); // regular case
            cout << "Insert D: Regular case passed!" << endl;
            D.insertDomestic("Royce", "Mancilla", 3.5, 100, 20222000, "BC"); // boundary/corner case
            cout << "Insert D: Boundary case passed!" << endl;
            D.insertDomestic("Royce", "Mancilla", 3.5, 101, 20222000, "BC"); // illegal case (research score > 100)
            // international
            T2.setScore(20,20,20,20);
            I.insertInternational("Royce", "Mancilla", 3.5, 90, 20222000, "Canada", T2); // regular case
            cout << "Insert I: Regular case passed!" << endl;
            I.insertInternational("Royce", "Mancilla", 3.5, 100, 20222000, "Canada", T2); // boundary/corner case 
            cout << "Insert I: Boundary case passed!" << endl;
            I.insertInternational("Royce", "Mancilla", 3.5, 101, 20222000, "Canada", T2); // illegal case (research score > 100)

            // testing search (application id, cgpa, research score)
            //domestic
            D.searchID(20220001); //regular case 
            cout << "SearchID D: Regular case passed!" << endl;
            D.searchID(20220100); // boundary case
            cout << "SearchID D: Boundary case passed!" << endl;
            D.searchID(17483040); // illegal case
            //international
            I.searchID(20220101); //regular case 
            cout << "SearchID I: Regular case passed!" << endl;
            I.searchID(20220200); // boundary case
            cout << "SearchID I: Boundary case passed!" << endl;
            I.searchID(17483040); // illegal case

            D.searchCGPA(3.70); //regular case 
            cout << "SearchCGPA D: Regular case passed!" << endl;
            D.searchCGPA(4.33); // boundary case
            cout << "SearchCGPA D: Boundary case passed!" << endl;
            D.searchCGPA(4.34); // illegal case
            //international
            I.searchCGPA(3.7); //regular case 
            cout << "SearchCGPA I: Regular case passed!" << endl;
            I.searchCGPA(4.33); // boundary case
            cout << "SearchCGPA I: Boundary case passed!" << endl;
            I.searchCGPA(4.85); // illegal case

            D.searchResearchScore(90); //regular case 
            cout << "SearchResearchScore D: Regular case passed!" << endl;
            D.searchResearchScore(100); // boundary case
            cout << "SearchResearchScore D: Boundary case passed!" << endl;
            D.searchResearchScore(101); // illegal case
            //international
            I.searchResearchScore(95); //regular case 
            cout << "SearchResearchScore I: Regular case passed!" << endl;
            I.searchResearchScore(100); // boundary case
            cout << "SearchResearchScore I: Boundary case passed!" << endl;
            I.searchResearchScore(101); // illegal case

            // testing search (firstName and lastName)
            D.searchName("Mary", "White"); //regular case 
            cout << "searchName D: Regular case passed!" << endl;
            D.searchName("MAry", "WHITe"); // boundary case
            cout << "searchName D: Boundary case passed!" << endl;
            D.searchName("Shiny", "Pond"); // illegal case
            //international
            I.searchName("Alex", "Zhang"); //regular case 
            cout << "searchName I: Regular case passed!" << endl;
            I.searchName("ALex", "ZHANg"); // boundary case
            cout << "searchName I: Boundary case passed!" << endl;
            I.searchName("Shiny", "Pond"); // illegal case

            // testing delete
            // domestic
            D.deleteDomestic("Mary", "White"); // regular case
            cout << "Delete D: Regular case passed!" << endl;
            D.deleteDomestic("", ""); // boundary/corner case
            cout << "Delete D: Boundary case passed!" << endl;
            D.deleteDomestic("Shiny", "Pond"); // illegal case (student not in list)
            //international
            I.deleteInternational("Alex", "Zhang"); // regular case
            cout << "Delete I: Regular case passed!" << endl;
            I.deleteInternational("", ""); // boundary/corner case
            cout << "Delete I: Boundary case passed!" << endl;
            I.deleteInternational("Shiny", "Pond"); // illegal case (student not in list)

            // testing delete head and tail node
            // domestic
            D.deleteHeadTail();
            cout << "DeleteHeadTail D: Regular case passed!" << endl; // regular case

            domesticList u_dom1; // creating a new object to test case where its just a head in list (boundary case)
            u_dom1.insertDomestic("Royce", "Mancilla", 3.5, 90, 20222000, "BC");
            u_dom1.deleteHeadTail();
            cout << "DeleteHeadTail D: Boundary case passed!" << endl;

            domesticList u_dom2; // creating a new object to test case of empty list (illegal case)
            u_dom2.deleteHeadTail();
            // international
            I.deleteHeadTail();
            cout << "DeleteHeadTail I: Regular case passed!" << endl; // regular case

            internationalList u_inter1; // creating a new object to test case where its just a head in list (boundary case)
            u_inter1.insertInternational("Royce", "Mancilla", 3.5, 90, 20222000, "Canada", T2);
            u_inter1.deleteHeadTail();
            cout << "DeleteHeadTail I: Boundary case passed!" << endl;

            internationalList u_inter2; // creating a new object to test case of empty list (illegal case)
            u_inter2.deleteHeadTail();

            // testing merge
            // code for merging D and I here 

            // testing search merged linked list
            // for regular case, do a cgpa threshold of 3.00 and research score threshold of 70
            // for boundary case, do a cgpa threshold of 4.33 and research score threshold of 100
            // for illegal case, do a cgpa threshold of 4.34 and research score threshold of 101
        }

        else if (menu_option2 != 1 || menu_option2 != 2 || menu_option2 != 3 || menu_option2 != 4)
        {
            cout << "The number you have entered is not a number on the menu" << endl;
        }

    } while (menu_option1 != EOF);

    return 0;
}
