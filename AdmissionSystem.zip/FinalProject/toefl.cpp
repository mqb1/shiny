// toefl.cpp to implement your classes
#include "toefl.hpp"

TOEFL::TOEFL()
{
    readingScore = 0;
    listeningScore = 0;
    speakingScore = 0;
    writingScore = 0;
    totalScore = 0;
}

TOEFL::TOEFL(const int newReadingScore, const int newListeningScore, const int newSpeakingScore, const int newWritingScore)
{
    readingScore = newReadingScore;
    listeningScore = newListeningScore;
    speakingScore = newSpeakingScore;
    writingScore = newWritingScore;
    totalScore = newReadingScore + newListeningScore + newSpeakingScore + newWritingScore;
}

void TOEFL::setScore(const int newReadingScore, const int newListeningScore, const int newSpeakingScore, const int newWritingScore)
{
    readingScore = newReadingScore;
    listeningScore = newListeningScore;
    speakingScore = newSpeakingScore;
    writingScore = newWritingScore;
    totalScore = newReadingScore + newListeningScore + newSpeakingScore + newWritingScore;
}

int TOEFL::getReadingScore(void) const
{
    return readingScore;
}

int TOEFL::getListeningScore(void) const
{
    return listeningScore;
}

int TOEFL::getSpeakingScore(void) const
{
    return speakingScore;
}

int TOEFL::getWritingScore(void) const
{
    return writingScore;
}

int TOEFL::getTotalScore(void) const
{
    return totalScore;
}