#ifndef INTERNATIONAL_HPP
#define INTERNATIONAL_HPP
#include <iostream>
#include <string>
#include "student.hpp"
#include "toefl.hpp"
using namespace std;

class international : public student
{
private:
    string country;
    TOEFL toeflScore;
    international *nextInternational;

public:
    international(void);
    international(const string &newFirstName, const string &newLastName, const float &newCGPA, const int &newResearchScore, const int &newStudentID, const string &newCountry, const TOEFL &newToeflScore);
    void setCountry(const string &newCountry);
    void setTOEFL(const TOEFL &newTOEFL);
    void setNextInternational(international *newNextInternaitonal);
    int getReadingScore(void) const;
    int getListeningScore(void) const;
    int getSpeakingScore(void) const;
    int getWritingScore(void) const;
    int getTotalScore(void) const;
    international *getNextInternational(void) const;
    string getCountry(void);
    friend int compareCountry(const international &international1, const international &international2);
    friend ostream &operator<<(ostream &outs, const international &international1);
};
#endif