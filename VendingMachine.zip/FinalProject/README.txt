

Mode: SW(1 downto 0)
passcode: SW(5 downto 2)
enter: SW(17)
product_valid: SW(16)
accept: SW(15)
product: SW(7 downto 6)
coins: SW(11 downto 8)

rst: SW(14)
hard_rst: KEY(3)